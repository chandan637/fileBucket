let users = [
    {
        id: 1,
        fullname: "Bucky"
    },
    {
        id: 2,
        fullname: "Joby"
    },
    {
        id: 3,
        fullname: "Madison"
    }
]
export default function (state = users, action) {
    switch (action.type) {
        case 'FILTER_USER':
                return users.filter(function (item) {
                    return item.fullname.toLowerCase().search(
                        action.payload.toLowerCase()) !== -1;
                });

            break;

        default:
            return state;
    }

}
