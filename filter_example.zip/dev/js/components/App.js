import React from 'react';
import connect from 'react-redux/lib/components/connect';
//import Sass file
//import '../scss/icons.scss';
import '../../scss/style.scss';


class App extends React.Component {
	constructor(props) {
        super(props);
		var self = this;
		this.state = {
        }	
    }
    gotoUrl(url){
        //console.log(url)
        this.context.router.push(url);
    }

	render() {
		return (
			<div>
               
				<ul type="none" className='custom'>
                <li onClick={this.gotoUrl.bind(this, "userlist")}>userdetail</li>
                <li onClick={this.gotoUrl.bind(this,"hello1")}>Hello1</li>
                <li onClick={this.gotoUrl.bind(this,"hello2")}>hello2</li>
                <li onClick={this.gotoUrl.bind(this,"hello3")}>Hello3</li>
                </ul>
                <div className='clear'></div>
                {this.props.children}
			</div>
		)
	}
}
App.contextTypes = {
    router: React.PropTypes.object.isRequired
}
function mapStateToProps(state) {
    return state;
}


export default connect(mapStateToProps)(App)
