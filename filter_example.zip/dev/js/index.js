import 'babel-polyfill';
import React from 'react';
import ReactDOM from "react-dom";
import {Provider} from 'react-redux';

import Router from 'react-router/lib/Router';
import Route from 'react-router/lib/Route';
import IndexRoute from 'react-router/lib/IndexRoute';
import hashHistory from 'react-router/lib/hashHistory';

import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import promise from 'redux-promise';
import createLogger from 'redux-logger';
import allReducers from './reducers';
import App from './components/App';
import UserList from './containers/user-list';
import Hello1 from './containers/hello-1';
import Hello2 from './containers/hello-2';
import Hello3 from './containers/hello-3';

const logger = createLogger();
const store = createStore(
    allReducers,
    applyMiddleware(thunk, promise, logger)
);

ReactDOM.render(
    <Provider store={store}>
        <Router history={hashHistory}>
			<Route path="/" component={App}>
				<IndexRoute component={UserList}></IndexRoute>
				<Route path="/userlist" component={UserList}>
				</Route>
				<Route path="/hello1" component={Hello1}>
				</Route>
				<Route path="/hello2" component={Hello2}>
				</Route>
                <Route path="/hello3" component={Hello3}>
				</Route>
			</Route>
		</Router>
    </Provider>,
    document.getElementById('root')
);
