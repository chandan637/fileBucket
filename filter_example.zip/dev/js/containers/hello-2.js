import React, {Component} from 'react';

/*
 * We need "if(!this.props.user)" because we set state to null by default
 * */

class Hello2 extends Component {
    render() {
        return (
            <div>
                 hello world 2
            </div>
        );
    }
}


export default Hello2;
